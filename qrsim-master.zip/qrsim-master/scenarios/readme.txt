This directory contains specific scenarios (i.e. applications) that can be simulated using qrsim.
