Any directory placed here is automatically added to the classpath (along with its subdirectories) by QRSim.

This is a simple way to use 3rd party libraries and functions along with QRSim.
