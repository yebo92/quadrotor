function [ ft ] = mToFt( m )
% MTOFT Converts from meters to feet
%   F = MTOFT(M)
%  
    ft=m./0.3048;
end
