function deg = radsToDegs(rad)
% RADSTODEGS Converts  angles from radians to degrees
%   DEG = RADSTODEGS(RAD)
%  
deg = (180./pi) .* rad;
