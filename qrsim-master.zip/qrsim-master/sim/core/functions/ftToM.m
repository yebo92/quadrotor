function m = ftToM( ft )
% FTTOM Converts from feet to meters
%   M = FTTOM(FT)
%  
    m=0.3048.*ft;
end

