This directory contains scripts and data used for code testing.
Their main purpouse is to aid code development therefore the code is often not commented and might change drastically between versions.
Some of the tests require a long time to run, while others depend on specific matlab toolboxes.
